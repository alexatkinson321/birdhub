const express = require('express');
const mysql = require('mysql');
const router = express.Router();
const { ensureAuthenticated } = require('../config/auth');

//create connection to db
const db = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    user: 'root',
    password: 'Sandollar1!', //change to env variable later on
    database: 'bird_db'
});

// connect to db
db.connect((err) => {
    if(err) throw err;
    console.log('MySql connected to index.js');
});

let classificationQuery = 'SELECT classification_id, classification FROM classification';
let subclassQuery = 'SELECT subclass_id, subclass FROM subclass ORDER BY subclass';
let beakQuery = 'SELECT beak_use_id AS beak_id, beak_use AS beak FROM beak_use ORDER BY beak_use';
let colorQuery = 'SELECT color_id, color FROM color';
let sizeQuery = 'SELECT size_id, size FROM size';
let dbClassification;
let dbSubclass;
let dbBeak;
let dbColor;
let dbSize;

db.query(classificationQuery, (err, result) => {
    if(err) throw err;
    dbClassification = result;
});

db.query(subclassQuery, (err, result) => {
    if(err) throw err;
    dbSubclass = result;
});

db.query(beakQuery, (err, result) => {
    if(err) throw err;
    dbBeak = result;
});

db.query(colorQuery, (err, result) => {
    if(err) throw err;
    dbColor = result;
});

db.query(sizeQuery, (err, result) => {
    if(err) throw err;
    dbSize = result;
});

//welcome page
router.get('/', (req, res) => res.render('welcome'));

//home page
router.get('/search', ensureAuthenticated, (req, res) => {
    res.render('search', {
        user: req.user[0],
        searchResults: null,
        classification: dbClassification,
        subclass: dbSubclass,
        beak: dbBeak,
        color: dbColor, 
        size: dbSize
    })
}); //pass user into home page, useable with ejs

router.post('/search', ensureAuthenticated, (req, res) => {

    let searchQuery = 
    `SELECT *
    FROM bird
    WHERE 1 = 1`;

    let {classification, subclass, main_color, size, beak_color, beak_use, 
    black, grey, white, brown, red, orange, yellow, green, blue, purple, pink} = req.body; //color returns color_id if checkbox is checked

    let colorsArray = [];
    let i =  0;

    if(black){
        colorsArray[i] = black;
        i++;
    }
    if(grey){
        colorsArray[i] = grey;
        i++;
    }
    if(white){
        colorsArray[i] = white;
        i++;
    }
    if(brown){
        colorsArray[i] = brown;
        i++;
    }
    if(red){
        colorsArray[i] = red;
        i++;
    }
    if(orange){
        colorsArray[i] = orange;
        i++;
    }
    if(yellow){
        colorsArray[i] = yellow;
        i++;
    }
    if(green){
        colorsArray[i] = green;
        i++;
    }
    if(blue){
        colorsArray[i] = blue;
        i++;
    }
    if(purple){
        colorsArray[i] = purple;
        i++;
    }
    if(pink){
        colorsArray[i] = pink;
        i++;
    }


    //WHERE clause builder
    if(classification){
        searchQuery += ` AND bird_classification_id = ${classification}`;
    }
    if(subclass){ 
        searchQuery += ` AND bird_subclass_id = ${subclass}`;
    }
    if(main_color){ 
        searchQuery += ` AND bird_main_color_id = ${main_color}`;
    }
    if(size){ 
        searchQuery += ` AND bird_size_id = ${size}`;
    }
    if(beak_color){
        searchQuery += ` AND bird_beak_color_id = ${beak_color}`;
    }
    if(beak_use){
        searchQuery += ` AND bird_beak_use_id = ${beak_use}`;
    }

    if(colorsArray.length > 0) {
        let colors = '';
        //IN clause builder
        for(let i = 0; i < colorsArray.length; i++){
            colors += colorsArray[i];
            if(i < colorsArray.length - 1){
                colors += ",";
            }
        }
        searchQuery += ` AND bird_id IN (SELECT bird_id FROM (SELECT COUNT(*) AS n, bird_id FROM bird_colors WHERE color_id IN (${colors}) GROUP BY bird_id HAVING n = ${colorsArray.length}) AS T);`
    }
    console.log(searchQuery);

    db.query(searchQuery, (err, result) => {
        if(err) throw err;
        searchResults = result;

        res.render('search', {
            searchResults: searchResults,
            user: req.user[0],
            classification: dbClassification,
            subclass: dbSubclass,
            beak: dbBeak,
            color: dbColor,
            size: dbSize
        });

    });
});

router.post('/search/sighting', ensureAuthenticated, (req, res) => {

    let updatedInput = { user_fname: '', user_lname: ''};
    let {sighting} = req.body;
    let sightingInsert = 
    `INSERT INTO bird_db.sighting (sighting_date, sighting_user_id, sighting_bird_id) 
    VALUES (CURDATE(), ${req.user[0].user_id}, ${sighting})`

    let sightingsQuery = 
    `SELECT DATE_FORMAT(sighting_date, '%m/%d/%Y') as date, sighting_id, bird_species, bird_image 
    FROM sighting 
    JOIN bird ON (sighting_bird_id = bird_id) 
    WHERE sighting_user_id = ${req.user[0].user_id} 
    ORDER BY sighting_date DESC`

    
        db.query(sightingInsert, (err, result) => {
            if(err) throw err;
            console.log("sighting added");
        });

    db.query(sightingsQuery, (err, result) => {
        if(err) throw err;
        userSightings = result;

        res.render('account', {
            user: req.user[0],
            updatedUser: updatedInput,
            userSightings: userSightings
        });
    });
});


module.exports = router;